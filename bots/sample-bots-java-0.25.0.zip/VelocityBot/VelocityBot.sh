#!/bin/sh
java -cp ../lib/* VelocityBot.java 
